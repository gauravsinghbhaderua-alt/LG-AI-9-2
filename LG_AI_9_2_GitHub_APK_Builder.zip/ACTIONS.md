# LG AI actions
Supported starter actions:
- Bluetooth -> opens system Bluetooth settings (modern Android requires system confirmation for enabling).
- Phone -> opens dialer; direct calls require explicit permission/user/system requirements.
- Torch -> implement CameraManager.setTorchMode after CAMERA permission and a compatible camera.
- App launcher -> use PackageManager to find installed launchable apps; launch only explicit user commands.
- Settings / camera / browser -> standard Android intents.

For cross-app editing, use Android's document picker and user-selected documents. Do not use accessibility as an unrestricted automation mechanism; Android documents AccessibilityService as an assistive technology and requires the user to enable it.
