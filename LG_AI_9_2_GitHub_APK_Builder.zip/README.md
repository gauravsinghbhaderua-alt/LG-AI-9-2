# LG AI — Advanced Offline Android Assistant
Android Studio/Kotlin project architecture for a local assistant.

Features:
- Local persistent memory (Room-ready repository, current starter uses JSON)
- Calculator
- Explicit Android actions: torch, settings, browser, camera, Bluetooth settings, dialer
- Foreground service scaffold for user-started background operation
- VoiceInteractionService scaffold for optional default-assistant integration
- GGUF/llama.cpp integration boundary (model binary is NOT bundled)
- User-selected document editing boundary
- Hindi/English command router
- Clean Material-style chat UI

Important:
Android restricts background microphone/service starts. Start voice/background features from visible UI or supported system assistant flows and show the required notification.
Bluetooth enable is requested through the system UI on modern Android; the app should not silently toggle it.
Phone calls use the system dialer/request flow; placing calls directly requires appropriate permission and user/system policy.
