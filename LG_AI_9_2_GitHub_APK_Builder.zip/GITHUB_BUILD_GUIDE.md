# LG AI 9.2 — GitHub APK Build

## Phone-only build

1. Create a GitHub repository and upload all files from this project.
2. Make sure `.github/workflows/build-apk.yml` is uploaded too.
3. Open the repository's **Actions** tab.
4. Select **Build LG AI APK**.
5. Tap **Run workflow**.
6. Wait for the build to finish.
7. Open the completed workflow run and scroll to **Artifacts**.
8. Download **LG-AI-9.2-debug-apk** and extract the APK.

The workflow builds a debug APK in GitHub's cloud runner. No USB cable is required.

## Important

- This builds the Android Studio source project; it does not add GGUF model weights.
- The project still needs a real GGUF/llama.cpp integration for local neural-model inference.
- Never put passwords, API keys, or private signing keys in the repository.
- A debug APK is suitable for testing. A release APK for distribution should be signed with your own keystore.
