# Local Neural / GGUF

The project intentionally does not bundle copyrighted/large model weights.

Recommended integration boundary:
1. Add llama.cpp Android native library/AAR.
2. Put a compatible `.gguf` model in app-private `models/` storage or let the user select one.
3. Wrap llama.cpp JNI calls behind `LocalLlmEngine`.
4. Stream tokens to the chat UI.
5. Before generation, build a context packet from MemoryStore + recent chat + current command.
6. After generation, optionally save a short user-approved memory.

Do not claim a GGUF model is running until the native library and model are actually loaded successfully.
