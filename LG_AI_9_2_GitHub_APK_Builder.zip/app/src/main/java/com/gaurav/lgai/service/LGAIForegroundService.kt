package com.gaurav.lgai.service
import android.app.*
import android.content.Intent
import android.os.IBinder
class LGAIForegroundService:Service(){
 override fun onStartCommand(i:Intent?,flags:Int,id:Int):Int{
  val ch=NotificationChannel("lgai","LG AI",NotificationManager.IMPORTANCE_LOW)
  getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
  val n=Notification.Builder(this,"lgai").setContentTitle("LG AI active").setContentText("Background assistant service is active").setSmallIcon(android.R.drawable.ic_dialog_info).build()
  startForeground(9,n); return START_STICKY
 }
 override fun onBind(i:Intent?):IBinder?=null
}
