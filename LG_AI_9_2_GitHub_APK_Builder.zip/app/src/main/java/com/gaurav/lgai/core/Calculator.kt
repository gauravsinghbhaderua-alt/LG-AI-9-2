package com.gaurav.lgai.core
object Calculator {
 fun eval(s:String):Double {
  val t=s.replace("×","*").replace("÷","/")
  val p=object { var i=0
   fun expr():Double{ var x=term(); while(i<t.length){ val c=t[i]; if(c!='+'&&c!='-') break; i++; val y=term(); x=if(c=='+')x+y else x-y }; return x }
   fun term():Double{ var x=power(); while(i<t.length){ val c=t[i]; if(c!='*'&&c!='/') break; i++; val y=power(); x=if(c=='*')x*y else x/y }; return x }
   fun power():Double{ var x=factor(); if(i<t.length&&t[i]=='^'){i++; x=Math.pow(x,power())}; return x}
   fun factor():Double{ while(i<t.length&&t[i].isWhitespace())i++; if(i<t.length&&t[i]=='('){i++; val x=expr(); if(i<t.length&&t[i]==')')i++; return x}; var st=i; while(i<t.length&&(t[i].isDigit()||t[i]=='.'||(i==st&&(t[i]=='-'||t[i]=='+'))))i++; return t.substring(st,i).toDouble() }
  }; return p.expr()
 }
}
