package com.gaurav.lgai.core
import android.content.Context
class MemoryStore(c:Context){
 private val p=c.getSharedPreferences("lg_memory",0)
 fun remember(text:String){ val old=p.getString("items","") ?: ""; p.edit().putString("items",(old+"\n"+text).takeLast(20000)).apply() }
 fun recall(query:String):String {
  val terms=query.lowercase().split(" ").filter{it.length>2}
  return (p.getString("items","")?:"").lines().filter{line->terms.any{line.lowercase().contains(it)}}.takeLast(8).joinToString("\n")
 }
}
