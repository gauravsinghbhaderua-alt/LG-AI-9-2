package com.gaurav.lgai.core
import android.content.*
import android.net.Uri
import android.provider.Settings
class CommandRouter(private val c:Context, private val memory:MemoryStore){
 fun handle(q:String):String {
  val x=q.trim(); val l=x.lowercase()
  if(l.startsWith("याद रखो")||l.startsWith("remember")){ val v=x.substringAfter(" ").trim(); memory.remember(v); return "ठीक है, मैंने इसे local memory में सेव किया।" }
  if(l.contains("क्या याद")||l.contains("what do you remember")) return memory.recall(x).ifBlank{"अभी relevant memory नहीं मिली।"}
  if(l.startsWith("गणना")||l.startsWith("calculate")) return try{ Calculator.eval(x.substringAfter(" ").trim()).toString() }catch(e:Exception){"Expression समझ नहीं आया।"}
  if(l.contains("ब्लूटूथ")){ c.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); return "Bluetooth settings खोल दी हैं; ON/OFF system से confirm करें।" }
  if(l.contains("सेटिंग")){ c.startActivity(Intent(Settings.ACTION_SETTINGS)); return "Settings खोल दी हैं।" }
  if(l.contains("कैमरा")){ c.startActivity(Intent("android.media.action.IMAGE_CAPTURE")); return "Camera खोल रहा हूँ।" }
  if(l.contains("ब्राउज़र")||l.contains("browser")){ c.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com"))); return "Browser खोल रहा हूँ।" }
  if(l.contains("फोन")||l.contains("call")||l.contains("कॉल")){ c.startActivity(Intent(Intent.ACTION_DIAL)); return "Dialer खोल दिया है; number और call आप confirm करें।" }
  return "मैंने command समझी: "$x". Local neural model जोड़ने पर मैं इसके लिए अधिक natural जवाब दूँगा।"
 }
}
