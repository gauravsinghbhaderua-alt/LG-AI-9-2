package com.gaurav.lgai.voice
import android.service.voice.VoiceInteractionService
class LGAIVoiceInteractionService:VoiceInteractionService(){
 override fun onReady(){ super.onReady() }
}
