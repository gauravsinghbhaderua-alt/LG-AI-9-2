package com.gaurav.lgai
import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.activity.ComponentActivity
import com.gaurav.lgai.core.CommandRouter
import com.gaurav.lgai.core.MemoryStore
import com.gaurav.lgai.service.LGAIForegroundService

class MainActivity: ComponentActivity() {
 private lateinit var chat: TextView; private lateinit var input: EditText
 private lateinit var router: CommandRouter
 override fun onCreate(b: Bundle?) { super.onCreate(b); setContentView(R.layout.activity_main)
  chat=findViewById(R.id.chat); input=findViewById(R.id.input)
  router=CommandRouter(this, MemoryStore(this))
  findViewById<Button>(R.id.send).setOnClickListener { val q=input.text.toString(); if(q.isNotBlank()){ append("You: $q"); append("LG AI: "+router.handle(q)); input.text.clear() } }
  findViewById<Button>(R.id.bg).setOnClickListener { startService(Intent(this,LGAIForegroundService::class.java)); append("LG AI: foreground assistant service started. Android will show its notification.") }
 }
 private fun append(s:String){ chat.append("\n$s\n") }
}
